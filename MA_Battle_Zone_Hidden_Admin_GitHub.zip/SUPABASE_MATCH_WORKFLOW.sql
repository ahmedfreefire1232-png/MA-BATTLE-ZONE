-- MA Battle Zone: secure custom-match workflow for the existing My Matches > Create 1v1 UI
-- Uses existing custom_matches, match_participants, match_results, profiles, wallets, wallet_transactions.
create or replace function public.mbz_create_custom_match(p_match_type text,p_title text,p_entry_fee numeric,p_scheduled_at timestamptz,p_rules text default '')
returns public.custom_matches language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); bal numeric; m public.custom_matches%rowtype; prize numeric;
begin
 if u is null then raise exception 'Please sign in first'; end if;
 if upper(trim(p_match_type)) not in ('CLASH SQUAD','LONE WOLF','LONE WOLF LOSS','LW LOSS') then raise exception 'Invalid match category'; end if;
 if p_entry_fee<=0 or p_entry_fee>100000 then raise exception 'Invalid entry fee'; end if;
 if p_scheduled_at<=now() then raise exception 'Match time must be in the future'; end if;
 select deposit_balance into bal from public.profiles where id=u for update;
 if not found then raise exception 'Player profile not found'; end if;
 if coalesce(bal,0)<p_entry_fee then raise exception 'Insufficient wallet coins'; end if;
 update public.profiles set deposit_balance=deposit_balance-p_entry_fee,updated_at=now() where id=u returning deposit_balance into bal;
 prize:=greatest(0,(p_entry_fee*2)-round(p_entry_fee*.3)-round(p_entry_fee*.1));
 insert into public.custom_matches(creator_id,match_type,title,description,entry_fee,prize_amount,max_players,players_count,scheduled_at,status,rules,entry_points)
 values(u,case when upper(trim(p_match_type))='LW LOSS' then 'Lone Wolf Loss' else initcap(lower(trim(p_match_type))) end,coalesce(nullif(trim(p_title),''),'Custom Match'),'Created from My Matches',p_entry_fee,prize,2,1,p_scheduled_at,'open',coalesce(p_rules,''),p_entry_fee)
 returning * into m;
 insert into public.match_participants(match_id,player_id,side,status,entry_fee_paid) values(m.id,u,'creator','joined',p_entry_fee);
 insert into public.wallet_transactions(player_id,transaction_type,amount,direction,balance_after,status,reference_table,reference_id,description)
 values(u,'custom_match_entry',p_entry_fee,'debit',bal,'completed','custom_match_entry',m.id,'Custom match entry fee');
 return m;
end $$;

create or replace function public.mbz_join_custom_match(p_match_id uuid)
returns public.custom_matches language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); m public.custom_matches%rowtype; bal numeric;
begin
 if u is null then raise exception 'Please sign in first'; end if;
 select * into m from public.custom_matches where id=p_match_id for update;
 if not found or m.status<>'open' then raise exception 'Match is not available'; end if;
 if m.creator_id=u then raise exception 'You cannot join your own match'; end if;
 if m.scheduled_at<=now() then raise exception 'Match time has passed'; end if;
 if exists(select 1 from public.match_participants where match_id=m.id and player_id=u) then raise exception 'You already joined this match'; end if;
 if m.players_count>=m.max_players then raise exception 'Match is full'; end if;
 select deposit_balance into bal from public.profiles where id=u for update;
 if coalesce(bal,0)<m.entry_fee then raise exception 'Insufficient wallet coins'; end if;
 update public.profiles set deposit_balance=deposit_balance-m.entry_fee,updated_at=now() where id=u returning deposit_balance into bal;
 insert into public.match_participants(match_id,player_id,side,status,entry_fee_paid) values(m.id,u,'opponent','joined',m.entry_fee);
 update public.custom_matches set players_count=players_count+1,status='joined',updated_at=now() where id=m.id returning * into m;
 insert into public.wallet_transactions(player_id,transaction_type,amount,direction,balance_after,status,reference_table,reference_id,description)
 values(u,'custom_match_entry',m.entry_fee,'debit',bal,'completed','custom_match_entry',m.id,'Joined custom match entry fee');
 return m;
end $$;

create or replace function public.mbz_refund_custom_match(p_match_id uuid) returns void language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); m public.custom_matches%rowtype; p record; bal numeric;
begin
 if u is null then raise exception 'Please sign in first'; end if;
 select * into m from public.custom_matches where id=p_match_id for update;
 if not found or m.creator_id<>u then raise exception 'Only the creator can refund this match'; end if;
 if m.scheduled_at is null or m.scheduled_at>now() then raise exception 'Refund unlocks after scheduled time'; end if;
 if exists(select 1 from public.match_participants where match_id=m.id and player_id<>m.creator_id and status='joined') then raise exception 'Opponent joined; refund is unavailable'; end if;
 if m.status='cancelled' or exists(select 1 from public.wallet_transactions where reference_table='custom_match_refund' and reference_id=m.id) then raise exception 'This match was already refunded'; end if;
 for p in select player_id,entry_fee_paid from public.match_participants where match_id=m.id and status='joined' loop
   update public.profiles set deposit_balance=deposit_balance+p.entry_fee_paid,updated_at=now() where id=p.player_id returning deposit_balance into bal;
   insert into public.wallet_transactions(player_id,transaction_type,amount,direction,balance_after,status,reference_table,reference_id,description)
   values(p.player_id,'custom_match_refund',p.entry_fee_paid,'credit',bal,'completed','custom_match_refund',m.id,'Expired match refund');
 end loop;
 update public.match_participants set status='refunded' where match_id=m.id and status='joined';
 update public.custom_matches set status='cancelled',updated_at=now() where id=m.id;
end $$;

create or replace function public.mbz_set_custom_match_room(p_match_id uuid,p_room_id text,p_room_password text) returns void language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); m public.custom_matches%rowtype;
begin
 if u is null then raise exception 'Please sign in first'; end if;
 select * into m from public.custom_matches where id=p_match_id for update;
 if not found or m.creator_id<>u then raise exception 'Only creator can set room details'; end if;
 if not exists(select 1 from public.match_participants where match_id=m.id and player_id<>u and status='joined') then raise exception 'Room details unlock after opponent joins'; end if;
 if nullif(trim(p_room_id),'') is null then raise exception 'Room ID is required'; end if;
 update public.custom_matches set room_id=trim(p_room_id),room_password=coalesce(trim(p_room_password),''),room_visible_at=now(),updated_at=now() where id=m.id;
end $$;

create or replace function public.mbz_submit_custom_match_result(p_match_id uuid,p_screenshot_path text,p_screenshot_url text) returns uuid language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); m public.custom_matches%rowtype; rid uuid;
begin
 if u is null then raise exception 'Please sign in first'; end if;
 select * into m from public.custom_matches where id=p_match_id for update;
 if not found or m.status in ('completed','cancelled') then raise exception 'Match is closed'; end if;
 if m.room_visible_at is null then raise exception 'Room ID and password must be set first'; end if;
 if not exists(select 1 from public.match_participants where match_id=m.id and player_id=u and status='joined') then raise exception 'Only match players can submit results'; end if;
 if exists(select 1 from public.match_results where match_id=m.id and submitted_by=u) then raise exception 'You already submitted your result'; end if;
 insert into public.match_results(match_id,submitted_by,result_type,screenshot_urls,status,notes)
 values(m.id,u,'custom',jsonb_build_array(jsonb_build_object('path',p_screenshot_path,'url',p_screenshot_url)),'pending','Player screenshot submission') returning id into rid;
 update public.match_participants set status='submitted' where match_id=m.id and player_id=u;
 update public.custom_matches set status='result_pending',updated_at=now() where id=m.id;
 return rid;
end $$;

create or replace function public.mbz_admin_settle_custom_match(p_match_id uuid,p_winner_id uuid,p_winner_payout numeric,p_loser_payout numeric,p_admin_note text default '') returns void language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid(); m public.custom_matches%rowtype; loser uuid; bal numeric;
begin
 if u is null or not public.is_admin() then raise exception 'Admin access required'; end if;
 if p_winner_payout<0 or p_loser_payout<0 then raise exception 'Payout cannot be negative'; end if;
 select * into m from public.custom_matches where id=p_match_id for update;
 if not found or m.status in ('completed','cancelled') then raise exception 'Match is already closed'; end if;
 if not exists(select 1 from public.match_results where match_id=m.id and status='pending') then raise exception 'No pending result screenshots'; end if;
 if not exists(select 1 from public.match_participants where match_id=m.id and player_id=p_winner_id and status in ('joined','submitted')) then raise exception 'Winner must be a match participant'; end if;
 select player_id into loser from public.match_participants where match_id=m.id and player_id<>p_winner_id and status in ('joined','submitted') limit 1;
 if loser is null then raise exception 'Opponent not found'; end if;
 update public.profiles set winning_balance=winning_balance+p_winner_payout,updated_at=now() where id=p_winner_id returning winning_balance into bal;
 insert into public.wallet_transactions(player_id,transaction_type,amount,direction,balance_after,status,reference_table,reference_id,description,metadata) values(p_winner_id,'custom_match_win',p_winner_payout,'credit',bal,'completed','custom_match_settlement',m.id,'Custom match winner payout',jsonb_build_object('match_id',m.id));
 update public.profiles set winning_balance=winning_balance+p_loser_payout,updated_at=now() where id=loser returning winning_balance into bal;
 insert into public.wallet_transactions(player_id,transaction_type,amount,direction,balance_after,status,reference_table,reference_id,description,metadata) values(loser,'custom_match_loser_reward',p_loser_payout,'credit',bal,'completed','custom_match_settlement',m.id,'Custom match loser reward',jsonb_build_object('match_id',m.id));
 update public.match_results set winner_id=p_winner_id,loser_id=loser,status='paid',winner_payout=p_winner_payout,loser_payout=p_loser_payout,admin_notes=coalesce(p_admin_note,''),reviewed_by=u,reviewed_at=now() where match_id=m.id and status='pending';
 update public.match_participants set status='completed' where match_id=m.id;
 update public.custom_matches set status='completed',updated_at=now() where id=m.id;
end $$;

create or replace function public.mbz_admin_approve_custom_match(p_match_id uuid,p_admin_note text default '') returns void language plpgsql security definer set search_path=public as $$
declare u uuid:=auth.uid();
begin
 if u is null or not public.is_admin() then raise exception 'Admin access required'; end if;
 if not exists(select 1 from public.custom_matches where id=p_match_id for update) then raise exception 'Match not found'; end if;
 if not exists(select 1 from public.match_results where match_id=p_match_id and status='pending') then raise exception 'No pending result screenshots'; end if;
 update public.match_results set status='approved',admin_notes=coalesce(p_admin_note,''),reviewed_by=u,reviewed_at=now() where match_id=p_match_id and status='pending';
 update public.match_participants set status='completed' where match_id=p_match_id;
 update public.custom_matches set status='completed',updated_at=now() where id=p_match_id;
end $$;


-- Read policies use a SECURITY DEFINER helper to avoid match_participants RLS recursion.
create or replace function public.mbz_is_match_player(p_match_id uuid,p_user_id uuid) returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.match_participants mp where mp.match_id=p_match_id and mp.player_id=p_user_id and mp.status in ('joined','submitted'));
$$;

alter table public.custom_matches enable row level security;
alter table public.match_participants enable row level security;
alter table public.match_results enable row level security;

drop policy if exists mbz_custom_matches_read on public.custom_matches;
create policy mbz_custom_matches_read on public.custom_matches for select to authenticated
 using (creator_id=auth.uid() or public.mbz_is_match_player(id,auth.uid()) or status='open' or public.is_admin());

drop policy if exists mbz_match_participants_read on public.match_participants;
create or replace function public.mbz_is_match_creator(p_match_id uuid,p_user_id uuid) returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.custom_matches cm where cm.id=p_match_id and cm.creator_id=p_user_id);
$$;

create policy mbz_match_participants_read on public.match_participants for select to authenticated
 using (player_id=auth.uid() or public.mbz_is_match_creator(match_id,auth.uid()) or public.is_admin());

drop policy if exists mbz_match_results_read on public.match_results;
create policy mbz_match_results_read on public.match_results for select to authenticated
 using (submitted_by=auth.uid() or public.mbz_is_match_player(match_id,auth.uid()) or public.is_admin());

-- Private screenshots: only match participants and admins can read; participant folder is their auth UID.
drop policy if exists mbz_match_screenshots_insert on storage.objects;
create policy mbz_match_screenshots_insert on storage.objects for insert to authenticated
 with check (bucket_id='ma-battle-zone' and (storage.foldername(name))[2]=auth.uid()::text);
drop policy if exists mbz_match_screenshots_read on storage.objects;
create policy mbz_match_screenshots_read on storage.objects for select to authenticated
 using (bucket_id='ma-battle-zone' and (public.mbz_is_match_player(((storage.foldername(name))[1])::uuid,auth.uid()) or public.mbz_is_match_creator(((storage.foldername(name))[1])::uuid,auth.uid()) or public.is_admin()));

grant execute on function public.mbz_is_match_player(uuid,uuid) to authenticated;
grant execute on function public.mbz_is_match_creator(uuid,uuid) to authenticated;

-- Storage setup for match screenshots. Keep bucket private.
insert into storage.buckets(id,name,public) values('ma-battle-zone','ma-battle-zone',false) on conflict(id) do update set public=false;
-- RLS is enabled for these tables; functions above perform all balance-changing operations transactionally.
grant execute on function public.mbz_create_custom_match(text,text,numeric,timestamptz,text) to authenticated;
grant execute on function public.mbz_join_custom_match(uuid) to authenticated;
grant execute on function public.mbz_refund_custom_match(uuid) to authenticated;
grant execute on function public.mbz_set_custom_match_room(uuid,text,text) to authenticated;
grant execute on function public.mbz_submit_custom_match_result(uuid,text,text) to authenticated;
grant execute on function public.mbz_admin_settle_custom_match(uuid,uuid,numeric,numeric,text) to authenticated;
grant execute on function public.mbz_admin_approve_custom_match(uuid,text) to authenticated;
