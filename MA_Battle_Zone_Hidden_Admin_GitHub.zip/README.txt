MA BATTLE ZONE — GITHUB-READY PANELS

Files:
- Player_Panel.html: player interface. Five quick taps on the visible "MA BATTLE ZONE" app title attempt to open Admin_Panel.html.
- Admin_Panel.html: separate admin interface with Supabase password login.
- SUPABASE_MATCH_WORKFLOW.sql: SQL workflow file supplied for the custom match RPCs/views/policies.

HIDDEN ADMIN ENTRY
1. Deploy Player_Panel.html and Admin_Panel.html in the same GitHub Pages folder/path.
2. Sign in to Player Panel as ahmedfreefire8@gmail.com.
3. Tap the "MA BATTLE ZONE" app title five times within about 2.5 seconds.
4. The browser checks the authenticated Supabase user's email and then calls public.is_admin(). Only if both checks pass does it navigate to Admin_Panel.html.
5. Admin_Panel.html independently checks the same email and public.is_admin() after login.

SECURITY
The five-tap trigger is only a hidden navigation shortcut, not a security boundary. Keep authorization in Supabase RLS/RPC policies and ensure public.is_admin() verifies a server-side admin role/allowlist. Never grant admin privileges based only on an email string supplied by the browser. Do not put a Supabase service-role key in either HTML file.

DEPLOYMENT
Keep both HTML files together at the same path so the relative Admin_Panel.html navigation works. The Supabase project URL and publishable/anon key are configured in the supplied HTML files. Review SQL against the live schema, back up the database, and test with separate player/admin accounts before production use.

LIMITS
This is a non-cash virtual-coins build. The SQL/HTML bundle has not been executed against the private live Supabase project; successful JavaScript parsing does not guarantee database schema/RPC compatibility.
